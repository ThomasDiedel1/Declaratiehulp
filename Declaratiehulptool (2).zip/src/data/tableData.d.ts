declare module "./tableData" {
  export const tableData: {
    [key: string]: {
      [key: string]: string | number | boolean; // Aangepast op basis van de verwachte data
    };
  };
}
