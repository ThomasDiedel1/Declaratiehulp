export const materiaalkosten = [
  { categorie: "MAT", omschrijving: "Minim oxybuprocaine", code: "OXY" },
  {
    categorie: "MAT",
    omschrijving: "Wrattenbehandeling met stikstof",
    code: "STI",
  },
  { categorie: "MAT", omschrijving: "Oogboring", code: "OOGB" },
  { categorie: "MAT", omschrijving: "Laboratorium kosten", code: "L" },
  {
    categorie: "MAT",
    omschrijving: "Materiaalkosten teststrip bloedsuiker",
    code: "BLS",
  },
  { categorie: "MAT", omschrijving: "Materiaalkosten dipslide", code: "DIP" },
  {
    categorie: "MAT",
    omschrijving: "Materiaalkosten atraumtisch hechtmateriaal",
    code: "HM",
  },
  { categorie: "MAT", omschrijving: "ECG diagnostiek", code: "ECG" },
  { categorie: "MAT", omschrijving: "Materiaalkosten CRP-test", code: "CRPC" },
];
