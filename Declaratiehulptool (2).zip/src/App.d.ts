declare const App: React.FC<any>;
export default App;