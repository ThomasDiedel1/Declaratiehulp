declare module "./DeclaratieTabel" {
  const DeclaratieTabel: React.FC<any>; // Hier geef je aan dat DeclaratieTabel een React functionele component is
  export default DeclaratieTabel;
}
