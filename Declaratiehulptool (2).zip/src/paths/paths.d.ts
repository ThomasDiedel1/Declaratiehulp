declare module "./paths" {
  export const paths: Record<string, any>; // Aannemende dat 'paths' een object is met een dynamisch aantal sleutels en waarden van elk type.
}
